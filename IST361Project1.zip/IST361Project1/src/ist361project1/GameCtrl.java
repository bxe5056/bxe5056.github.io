package ist361project1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GameCtrl {

    private GameUI gameUI;

    private GameOverUI gameOverUI;

    GameCtrl(GameModel model, GameUI ui) {

        gameUI = ui;

        gameOverUI = new GameOverUI();
        
        gameUI.getLoseBtn().addActionListener(new GameOverListener());

    }
    
    class GameOverListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            gameOverUI.setVisible(true);

        }
    }

    public GameOverUI getGameOverUI() {
        return gameOverUI;
    }

    public GameUI getGameUI() {
        return gameUI;
    }

}
