
package ist361project1;

public class GameModel {
    
}
