package ist361project1;

import static java.awt.Component.CENTER_ALIGNMENT;
import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class GameOverUI extends JFrame {

    private JPanel panel;
    private JLabel title;
    private JLabel scoreText;
    private JLabel score;
    private JLabel level;
    private JLabel inputText;
    private JTextField nameField;
    private JButton submitBtn;

    public GameOverUI() {

        panel = new JPanel();
        title = new JLabel("Game Over!");
        scoreText = new JLabel("Your Score:");
        score = new JLabel("100");
        level = new JLabel("Level 2");
        inputText = new JLabel("Enter Your Name:");
        nameField = new JTextField(10);
        submitBtn = new JButton("Submit");

        this.setSize(500, 500);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(dim.width / 2 - this.getSize().width / 2, dim.height / 2 - this.getSize().height / 2);
        this.setTitle("Game Over!");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);

        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        nameField.setMaximumSize(nameField.getPreferredSize());

        panel.add(title);
        panel.add(scoreText);
        panel.add(score);
        panel.add(level);
        panel.add(inputText);
        panel.add(nameField);
        panel.add(submitBtn);

        this.add(panel);

        title.setAlignmentX(CENTER_ALIGNMENT);
        scoreText.setAlignmentX(CENTER_ALIGNMENT);
        score.setAlignmentX(CENTER_ALIGNMENT);
        level.setAlignmentX(CENTER_ALIGNMENT);
        inputText.setAlignmentX(CENTER_ALIGNMENT);
        nameField.setAlignmentX(CENTER_ALIGNMENT);
        submitBtn.setAlignmentX(CENTER_ALIGNMENT);

        this.setVisible(false);

    }

    public JTextField getNameField() {
        return nameField;
    }

    public JButton getSubmitBtn() {
        return submitBtn;
    }

}
