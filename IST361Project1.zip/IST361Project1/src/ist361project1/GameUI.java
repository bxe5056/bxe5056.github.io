package ist361project1;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;

public class GameUI extends JFrame {

    private GameModel gameModel;

    public JPanel buttonPanel;
    int score;
    private JButton exitBtn;
    private JButton loseBtn;

    public GameUI(GameModel model) {
        gameModel = model;

        score = 50;
        buttonPanel = new JPanel();

        this.setSize(800, 600);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(dim.width / 2 - this.getSize().width / 2, dim.height / 2 - this.getSize().height / 2);
        this.setTitle("Munchers - Level X");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);

        exitBtn = new JButton("Exit to Menu");
        loseBtn = new JButton("Game Over");

        buttonPanel.add(exitBtn);
        buttonPanel.add(loseBtn);

        this.add(buttonPanel);

        this.setVisible(false);
    }

    public JButton getExitBtn() {
        return exitBtn;
    }

    public JButton getLoseBtn() {
        return loseBtn;
    }

    public int getScore() {
        return score;
    }

}
