
package ist361project1;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class InstructionsUI extends JPanel {

    private JLabel title;

    private JLabel instructions;

    private JButton exitBtn;

    InstructionsUI() {

        this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        title = new JLabel("Instructions");
        title.setFont(title.getFont().deriveFont(40.0f));

        instructions = new JLabel("<html><ul>" +
        "<li>User moves around a grid of numbers using the arrow keys</li>" +             
        "<li>The user presses the space key when in a given cell to select it</li>" + 
        "<li>The goal is to correctly select numbers that meet specific criteria</li>" + 
        "<li>Correctly selected cells turn green and the user gains points</li>" +
        "<li>Incorrectly selected cells turn red</li>" +
        "<li>A timer is also used in each level, and resets on each new level</li>" +
        "</ul><html>");

        exitBtn = new JButton("Back");

        title.setAlignmentX(CENTER_ALIGNMENT);
        instructions.setAlignmentX(CENTER_ALIGNMENT);
        exitBtn.setAlignmentX(CENTER_ALIGNMENT);

        this.add(title);
        this.add(instructions);
        this.add(exitBtn);

    }

    public JButton getExitBtn() {
        return exitBtn;
    }

}
