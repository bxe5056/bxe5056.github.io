
package ist361project1;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class LevelSelectUI extends JPanel {

    private JLabel title;

    private JLabel text;

    private ButtonGroup lvlBtnGrp;
    private JRadioButton lvl1Btn;
    private JRadioButton lvl2Btn;
    private JRadioButton lvl3Btn;
    private JRadioButton lvl4Btn;

    private JButton playBtn;
    private JButton exitBtn;

    LevelSelectUI() {

        this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        title = new JLabel("Level Select");
        title.setFont(title.getFont().deriveFont(40.0f));

        text = new JLabel("Choose a level:");

        lvlBtnGrp = new ButtonGroup();
        lvl1Btn = new JRadioButton("Level 1");
        lvl2Btn = new JRadioButton("Level 2");
        lvl3Btn = new JRadioButton("Level 3");
        lvl4Btn = new JRadioButton("Level 4");
        lvlBtnGrp.add(lvl1Btn);
        lvlBtnGrp.add(lvl2Btn);
        lvlBtnGrp.add(lvl3Btn);
        lvlBtnGrp.add(lvl4Btn);

        playBtn = new JButton("Play");
        exitBtn = new JButton("Back");

        title.setAlignmentX(CENTER_ALIGNMENT);
        text.setAlignmentX(CENTER_ALIGNMENT);
        lvl1Btn.setAlignmentX(CENTER_ALIGNMENT);
        lvl2Btn.setAlignmentX(CENTER_ALIGNMENT);
        lvl3Btn.setAlignmentX(CENTER_ALIGNMENT);
        lvl4Btn.setAlignmentX(CENTER_ALIGNMENT);
        playBtn.setAlignmentX(CENTER_ALIGNMENT);
        exitBtn.setAlignmentX(CENTER_ALIGNMENT);

        this.add(title);
        this.add(text);
        this.add(lvl1Btn);
        this.add(lvl2Btn);
        this.add(lvl3Btn);
        this.add(lvl4Btn);
        this.add(playBtn);
        this.add(exitBtn);

    }

    public JButton getExitBtn() {
        return exitBtn;
    }

    public JRadioButton getLvl1Btn() {
        return lvl1Btn;
    }

    public JRadioButton getLvl2Btn() {
        return lvl2Btn;
    }

    public JRadioButton getLvl3Btn() {
        return lvl3Btn;
    }

    public JRadioButton getLvl4Btn() {
        return lvl4Btn;
    }

    public ButtonGroup getLvlBtnGrp() {
        return lvlBtnGrp;
    }

    public JButton getPlayBtn() {
        return playBtn;
    }

}
