
package ist361project1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainMenuCtrl {

    private MenuModel menuModel;

    //UI
    private MenuUI menuUI;
    private LevelSelectUI levelSelectUI;
    private InstructionsUI instructionsUI;
    private ScoreUI scoreUI;

    GameModel gameModel;
    GameUI gameUI;
    GameCtrl gameCtrl;
    
    

    MainMenuCtrl(MenuModel model, MenuUI ui) {

        menuModel = model;

        //UI
        menuUI = ui;
        levelSelectUI = new LevelSelectUI();
        instructionsUI = new InstructionsUI();
        scoreUI = new ScoreUI();

        gameModel = new GameModel();
        gameUI = new GameUI(gameModel);
        gameCtrl = new GameCtrl(gameModel, gameUI);
        
        

        //Menu Listeners
        menuUI.getStartBtn().addActionListener(new StartListener());
        menuUI.getInstructionsBtn().addActionListener(new InstructionListener());
        menuUI.getScoreBtn().addActionListener(new ScoreListener());
        menuUI.getExitBtn().addActionListener(new ExitListener());

        //SubMenu Listeners
        levelSelectUI.getLvl1Btn().addActionListener(new LevelSelectListener());
        levelSelectUI.getLvl2Btn().addActionListener(new LevelSelectListener());
        levelSelectUI.getLvl3Btn().addActionListener(new LevelSelectListener());
        levelSelectUI.getLvl4Btn().addActionListener(new LevelSelectListener());
        levelSelectUI.getPlayBtn().addActionListener(new PlayGameListener());
        levelSelectUI.getExitBtn().addActionListener(new MenuExitListener());

        instructionsUI.getExitBtn().addActionListener(new MenuExitListener());
        scoreUI.getExitBtn().addActionListener(new MenuExitListener());
        
        //Game Listeners
        gameCtrl.getGameUI().getExitBtn().addActionListener(new ExitGameListener());
        
        //Game Over Listeners
        gameCtrl.getGameOverUI().getSubmitBtn().addActionListener(new SubmitScoreListener());
        

    }

    class StartListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            menuUI.remove(menuUI.getMenuPanel());
            menuUI.add(levelSelectUI);
            menuUI.repaint();
            menuUI.revalidate();

        }
    }

    class InstructionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            menuUI.remove(menuUI.getMenuPanel());
            menuUI.add(instructionsUI);
            menuUI.repaint();
            menuUI.revalidate();

        }
    }

    class ScoreListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            menuUI.remove(menuUI.getMenuPanel());
            scoreUI.getScoreList().setText(menuModel.getScoreString());
            
            menuUI.add(scoreUI);
            menuUI.repaint();
            menuUI.revalidate();

        }
    }

    class MenuExitListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            menuUI.remove(levelSelectUI);
            menuUI.remove(instructionsUI);
            menuUI.remove(scoreUI);
            menuUI.add(menuUI.getMenuPanel());
            menuUI.repaint();
            menuUI.revalidate();

        }
    }

    class LevelSelectListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (levelSelectUI.getLvl1Btn().isSelected()) {
                //Action on selection
            } else if (levelSelectUI.getLvl2Btn().isSelected()) {
                //Action on selection
            } else if (levelSelectUI.getLvl3Btn().isSelected()) {
                //Action on selection
            } else if (levelSelectUI.getLvl4Btn().isSelected()) {
                //Action on selection
            } else {
            }
        }
    }

    class PlayGameListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            menuUI.setVisible(false);
            gameCtrl.getGameUI().setVisible(true);

        }
    }

    class ExitGameListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            menuUI.setVisible(true);
            gameCtrl.getGameUI().setVisible(false);
            gameCtrl.getGameOverUI().setVisible(false);
            

        }
    }
    
    class SubmitScoreListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            menuUI.setVisible(true);
            gameCtrl.getGameUI().setVisible(false);
            gameCtrl.getGameOverUI().setVisible(false);
            
            menuModel.addScore(gameCtrl.getGameOverUI().getName(), gameCtrl.getGameUI().getScore());
        }
    }

    class ExitListener implements ActionListener {
        
        @Override
        public void actionPerformed(ActionEvent e) {
            
            menuUI.dispose();
            System.exit(0);
        }
    }

    public MenuModel getMenuModel() {
        return menuModel;
    }

    public MenuUI getMenuUI() {
        return menuUI;
    }

    public LevelSelectUI getLevelSelectUI() {
        return levelSelectUI;
    }

    public InstructionsUI getInstructionsUI() {
        return instructionsUI;
    }

    public ScoreUI getScoreUI() {
        return scoreUI;
    }

}
