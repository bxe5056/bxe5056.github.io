package ist361project1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MenuModel {

    private ArrayList<Score> scores;
    private static final String SCORE_FILE = "src/ist361project1/scores.dat";

    ObjectOutputStream outputStream = null;
    ObjectInputStream inputStream = null;

    public MenuModel() {

        scores = new ArrayList<>();

    }

    public ArrayList<Score> getScores() {
        loadScoreFile();
        sort();
        return scores;
    }

    private void sort() {
        ScoreComparator comparator = new ScoreComparator();
        Collections.sort(scores, comparator);
    }

    public void addScore(String name, int score) {
        loadScoreFile();
        scores.add(new Score(name, score));
        updateScoreFile();
    }

    public void loadScoreFile() {
        try {
            inputStream = new ObjectInputStream(new FileInputStream(SCORE_FILE));
            scores = (ArrayList<Score>) inputStream.readObject();
        } catch (FileNotFoundException e) {
            System.out.println("[Laad] FNF Error: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("[Laad] IO Error: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("[Laad] CNF Error: " + e.getMessage());
        } finally {
            try {
                if (outputStream != null) {
                    outputStream.flush();
                    outputStream.close();
                }
            } catch (IOException e) {
                System.out.println("[Laad] IO Error: " + e.getMessage());
            }
        }
    }

    public void updateScoreFile() {
        try {
            outputStream = new ObjectOutputStream(new FileOutputStream(SCORE_FILE));
            outputStream.writeObject(scores);
        } catch (FileNotFoundException e) {
            System.out.println("[Update] FNF Error: " + e.getMessage() + ",the program will try and make a new file");
        } catch (IOException e) {
            System.out.println("[Update] IO Error: " + e.getMessage());
        } finally {
            try {
                if (outputStream != null) {
                    outputStream.flush();
                    outputStream.close();
                }
            } catch (IOException e) {
                System.out.println("[Update] Error: " + e.getMessage());
            }
        }
    }

    public String getScoreString() {
        String highscoreString = "";
        int max = 10;

        ArrayList<Score> workingScores;
        workingScores = getScores();

        int i = 0;
        int x = workingScores.size();
        if (x > max) {
            x = max;
        }
        while (i < x) {
            highscoreString += (i + 1) + ".\t" + workingScores.get(i).getName() + "\t\t" + workingScores.get(i).getScore() + "\n";
            i++;
        }
        return highscoreString;
    }

    class ScoreComparator implements Comparator<Score> {

        public int compare(Score score1, Score score2) {
            int sc1 = score1.getScore();
            int sc2 = score2.getScore();
            if (sc1 > sc2) {
                return -1;
            } else if (sc1 < sc2) {
                return 1;
            } else {
                return 0;
            }
        }
    }

}
