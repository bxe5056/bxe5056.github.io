package ist361project1;

import java.awt.*;
import javax.swing.*;

public class MenuUI extends JFrame {

    private MenuModel menuModel;

    private JPanel menuPanel;

    private JLabel title;

    private JButton startBtn;
    private JButton scoreBtn;
    private JButton exitBtn;
    private JButton instructionsBtn;

    public MenuUI(MenuModel model) {

        this.setSize(new Dimension(800, 600));
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(dim.width / 2 - this.getSize().width / 2, dim.height / 2 - this.getSize().height / 2);
        this.setTitle("Munchers");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        menuModel = model;

        menuPanel = new JPanel();
        menuPanel.setLayout(new BoxLayout(menuPanel, BoxLayout.Y_AXIS));

        title = new JLabel("Munchers");
        title.setFont(title.getFont().deriveFont(40.0f));

        startBtn = new JButton("Start");
        instructionsBtn = new JButton("Instructions");
        scoreBtn = new JButton("Leaderboard");
        exitBtn = new JButton("Exit");

        title.setAlignmentX(CENTER_ALIGNMENT);
        startBtn.setAlignmentX(CENTER_ALIGNMENT);
        instructionsBtn.setAlignmentX(CENTER_ALIGNMENT);
        scoreBtn.setAlignmentX(CENTER_ALIGNMENT);
        exitBtn.setAlignmentX(CENTER_ALIGNMENT);

        menuPanel.add(title);
        menuPanel.add(startBtn);
        menuPanel.add(instructionsBtn);
        menuPanel.add(scoreBtn);
        menuPanel.add(exitBtn);

        this.add(menuPanel);

        this.setVisible(true);

    }

    public JButton getStartBtn() {
        return startBtn;
    }

    public JButton getScoreBtn() {
        return scoreBtn;
    }

    public JButton getExitBtn() {
        return exitBtn;
    }

    public JButton getInstructionsBtn() {
        return instructionsBtn;
    }

    public JPanel getMenuPanel() {
        return menuPanel;
    }

}
