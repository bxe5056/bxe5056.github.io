
package ist361project1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Muncher {

    public static void main(String[] args) {

        MenuModel menuModel = new MenuModel();
        MenuUI menuUI = new MenuUI(menuModel);
        MainMenuCtrl menuCtrl = new MainMenuCtrl(menuModel, menuUI);

    }

}
