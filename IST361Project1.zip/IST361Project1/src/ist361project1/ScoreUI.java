
package ist361project1;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

public class ScoreUI extends JPanel {

    private JLabel title;

    private JTextPane scoreList;

    private JButton exitBtn;

    ScoreUI() {

        this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        title = new JLabel("Leaderboard");
        title.setFont(title.getFont().deriveFont(40.0f));

        scoreList = new JTextPane();

        exitBtn = new JButton("Back");

        title.setAlignmentX(CENTER_ALIGNMENT);
        
        scoreList.setAlignmentX(CENTER_ALIGNMENT);
        StyledDocument doc = scoreList.getStyledDocument();
        SimpleAttributeSet center = new SimpleAttributeSet();
        StyleConstants.setAlignment(center, StyleConstants.ALIGN_CENTER);
        doc.setParagraphAttributes(0, doc.getLength(), center, false);
        
        exitBtn.setAlignmentX(CENTER_ALIGNMENT);

        this.add(title);
        this.add(scoreList);
        this.add(exitBtn);

    }

    public JButton getExitBtn() {
        return exitBtn;
    }

    public JTextPane getScoreList() {
        return scoreList;
    }

}
